<?php
require("connect.php");
$email = $_GET["email"];
mysqli_query($con,"DELETE FROM `contact_details` WHERE `email`='$email'");
echo'
<script>
alert("Record have been deleted");
window.location.href = "details.php";
</script>
';
?>