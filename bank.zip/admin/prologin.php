<?php
require("connect.php");
if(isset($_POST["sign"])){
	$user = $_POST["username"];
	$pass = $_POST["password"];
	$query = mysqli_query($con,"SELECT * FROM `admin` WHERE `username`='$user' AND `password`='$pass'");
	if(mysqli_fetch_assoc($query)){
		session_start();
		$_SESSION["username"] = $user;
		header("location:index.php");
	}else{
		echo'
	<script>
    alert("Username and Password is incorrect");
    window.location.href = "admin_login.html";
	</script>
	';
	}

}
?>
