<?php
require("connect.php");
$email = $_GET["email"];
mysqli_query($con,"DELETE FROM `security` WHERE `email`='$email'");
echo'
<script>
alert("Record have been deleted");
window.location.href = "security.php";
</script>
';
?>