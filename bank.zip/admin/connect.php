<?php
$con = mysqli_connect("localhost","oceans_goof","fuG[RPZ9W7dF","oceans_goof");
?>