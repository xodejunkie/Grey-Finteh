<?php
require("connect.php");
$sn = $_GET["sn"];
mysqli_query($con,"DELETE FROM `sttp_transfer` WHERE `sn`='$sn'");
echo'
<script>
alert("Record have been deleted");
window.location.href = "stp_transaction.php";
</script>
';
?>