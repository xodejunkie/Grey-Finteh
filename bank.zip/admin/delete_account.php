<?php
require("connect.php");
$email = $_GET["email"];
mysqli_query($con,"DELETE FROM `account` WHERE `email`='$email'");
echo'
<script>
alert("Record have been deleted");
window.location.href = "account.php";
</script>
';
?>